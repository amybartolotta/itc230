var expect = require("chai").expect;
var movie = require("../lib/movie");
describe("movie module", () => {
 it("returns requested movie", function() {
   var result = movie.get("dune");
   expect(result).to.deep.equal({title: "jaws", director:"stephen spielberg", date:1975});
 });
 
 it("fails w/ invalid movie", () => {
   var result = movie.get("fake");
   expect(result).to.be.undefined;
 });
});